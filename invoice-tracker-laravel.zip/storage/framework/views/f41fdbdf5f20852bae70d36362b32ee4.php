<?php $__env->startSection('title', 'Cek Posisi Invoice'); ?>

<?php $__env->startSection('content'); ?>
<section class="public-page">
  <div class="topbar"><div class="topbar-inner">
    <div class="brand"><span class="brand-mark">IF</span><div>Invoice Tracker<small>Pelacakan aman</small></div></div>
    <div class="top-actions">
      <button data-theme-toggle class="btn btn-soft icon-btn" type="button">◐</button>
      <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">Dashboard</a>
      <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Dashboard</a>
      <?php endif; ?>
    </div>
  </div></div>

  <div class="public-wrap">
    <div class="public-title"><h1>Cek Posisi Invoice</h1><p>Pindai QR pada tanda terima atau masukkan kode akses rahasia.</p></div>
    <form method="GET" action="<?php echo e(route('tracking.index')); ?>" class="searchbar">
      <input name="code" value="<?php echo e($query); ?>" required minlength="64" maxlength="64" autocomplete="off" placeholder="Kode akses 64 karakter">
      <button class="btn btn-primary" type="submit">Cari</button>
    </form>
    <p class="muted" style="text-align:center;margin:-10px 0 20px;font-size:11px">Nomor invoice, PO, dan tanda terima tidak dapat digunakan untuk pencarian publik.</p>

    <div class="public-result">
      <?php if($error): ?>
        <div class="result-card" style="text-align:center;color:var(--danger)"><?php echo e($error); ?></div>
      <?php elseif($query !== '' && count($results) === 0): ?>
        <div class="result-card" style="text-align:center;color:var(--muted)">Kode akses tidak valid.</div>
      <?php endif; ?>

      <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="result-card">
          <div class="result-head">
            <div>
              <strong style="font-size:17px"><?php echo e($inv['receiptNo'] ?: $inv['invoiceNo']); ?></strong>
              <div class="muted" style="font-size:12px;margin-top:3px">Invoice: <?php echo e($inv['invoiceNo'] ?: '-'); ?> · <?php echo e($inv['supplier']); ?></div>
            </div>
            <span class="badge <?php echo e($inv['status'] === 'Selesai' ? 'green' : ($inv['status'] === 'Batal' ? 'red' : 'gray')); ?>"><?php echo e($inv['status']); ?></span>
          </div>
          <div class="result-grid">
            <div class="info"><small>Posisi Sekarang</small><strong><?php echo e($inv['position'] ?: '-'); ?></strong></div>
            <div class="info"><small>PIC / User</small><strong><?php echo e($inv['picUser'] ?: '-'); ?></strong></div>
            <div class="info"><small>Jatuh Tempo</small><strong><?php echo e($inv['dueDate'] ?: '-'); ?> · <?php echo e($inv['dueStatus']); ?></strong></div>
            <div class="info"><small>Kekurangan</small><strong><?php echo e($inv['missingDocuments'] ?: 'Lengkap'); ?></strong></div>
          </div>
          <?php if(!empty($inv['timeline'])): ?>
            <div class="public-timeline"><strong>Perjalanan invoice</strong><div class="timeline" style="margin-top:10px">
              <?php $__currentLoopData = array_slice($inv['timeline'], 0, 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="timeline-item"><div class="timeline-dot"></div><div class="timeline-card"><strong><?php echo e($h['toStatus'] ?: '-'); ?></strong><div class="timeline-meta"><?php echo e($h['time']); ?></div></div></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div></div>
          <?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="muted" style="text-align:center;margin-top:16px;font-size:11px">Invoice Tracker · Akses dilindungi kode acak</div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\projects\invoice-tracker-laravel\resources\views/tracking/index.blade.php ENDPATH**/ ?>