

<?php $__env->startSection('title', 'Login - Invoice Tracker'); ?>

<?php $__env->startSection('content'); ?>
<section class="login-page">
  <div class="login-wrap"><div class="login-card">
    <h2>Login Invoice Tracker</h2>
    <p>Dashboard otomatis menyesuaikan role akun.</p>

    <?php if($errors->any()): ?>
      <div class="status-note" style="margin-bottom:14px"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login.store')); ?>">
      <?php echo csrf_field(); ?>
      <div class="field"><label>Username</label><input name="username" value="<?php echo e(old('username')); ?>" autocomplete="username" required autofocus></div>
      <div class="field"><label>Password</label><input name="password" type="password" autocomplete="current-password" required></div>
      <div class="login-actions">
        <a class="btn btn-soft" href="<?php echo e(route('tracking.index')); ?>">Kembali</a>
        <button class="btn btn-primary" type="submit">Login</button>
      </div>
    </form>
  </div></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\projects\invoice-tracker-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>