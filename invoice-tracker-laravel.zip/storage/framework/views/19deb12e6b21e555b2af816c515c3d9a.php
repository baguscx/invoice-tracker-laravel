<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('title', 'Invoice Tracker'); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
<?php
  $roleLabels = ['ADMIN' => 'Admin', 'RESEPSIONIS' => 'Resepsionis', 'USER' => 'User / PIC', 'ACCOUNTING' => 'Accounting'];
  $workspaceLabels = ['ADMIN' => 'Control Center', 'RESEPSIONIS' => 'Meja Resepsionis', 'USER' => 'Tugas User / PIC', 'ACCOUNTING' => 'Meja Accounting'];
  $authUser = auth()->user();
?>
<section id="dashboardPage" class="shell">
  <div class="topbar"><div class="topbar-inner">
    <div class="brand"><span class="brand-mark">IF</span><div>Invoice Tracker<small><?php echo e($workspaceLabels[$authUser->role] ?? 'Workspace'); ?></small></div></div>
    <div class="top-actions">
      <div class="user-chip"><span class="name"><?php echo e($authUser->name); ?></span><span class="role-pill"><?php echo e($roleLabels[$authUser->role] ?? $authUser->role); ?></span></div>
      <button id="themeBtn" class="btn btn-soft icon-btn" type="button" title="Ganti tema">◐</button>
      <a href="<?php echo e(route('tracking.index')); ?>" class="btn btn-soft">Cek Publik ↗</a>
      <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin:0">
        <?php echo csrf_field(); ?>
        <button class="btn btn-danger" type="submit">Logout</button>
      </form>
    </div>
  </div></div>

  <main class="container">
    <?php echo $__env->yieldContent('content'); ?>
  </main>
</section>

<?php echo $__env->make('partials.modals', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
window.InvoiceTracker = <?php echo json_encode($bootstrap, 15, 512) ?>;
</script>
<script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\projects\invoice-tracker-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>